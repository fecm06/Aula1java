import jdk.nashorn.internal.ir.IfNode;

public class ExerciciosAula1java{
    public static void main(String[] args){
    //1
    public Integer numeroA = 2;
    public double numeroB = 3;
    public String umaCadeiadeTexto = "Hello World";

    System.out.println(numeroA + numeroB);
    System.out.println(numeroA - numeroB);

    //2

        If(numeroA>numeroB);
        System.out.println(false);
        else if (numeroA<numeroB);
        System.out.println(True);
        else void()



}
